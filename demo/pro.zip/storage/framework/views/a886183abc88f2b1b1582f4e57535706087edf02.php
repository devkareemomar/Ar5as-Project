<?php if($errors->any()): ?>
<div class="bs-component">
    <div class="alert alert-danger alert-dismissible ">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button class="close" type="button" data-dismiss="alert">×</button><strong><?php echo e($error); ?>!</strong>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>  
<?php endif; ?><?php /**PATH C:\xampp\htdocs\demo\resources\views/partials/_errors.blade.php ENDPATH**/ ?>