<!-- Top Bar -->

<!-- END Top Bar -->
<header class="<?php if(get_setting('header_stikcy') == 'on'): ?> sticky-top <?php endif; ?> z-1020 bg-white border-bottom shadow-sm">
    <div class="position-relative logo-bar-area">
        <div class="container">
            <div class="d-flex align-items-center">

                <div class="col-auto col-xl-3 pl-0 pr-3 d-flex align-items-center">
                    <a class="d-block py-20px mr-3 ml-0" href="<?php echo e(route('home')); ?>">
                        <?php
                            $header_logo = get_setting('header_logo');
                        ?>
                        <?php if($header_logo != null): ?>
                            <img src="<?php echo e(uploaded_asset($header_logo)); ?>" alt="<?php echo e(env('APP_NAME')); ?>" class="mw-100" height="50"> 
                        <?php else: ?>
                            <img src="<?php echo e(static_asset('assets/img/logo.png')); ?>" alt="<?php echo e(env('APP_NAME')); ?>" class="mw-100 h-30px h-md-40px" height="40">
                        <?php endif; ?>
                    </a>

                    <?php if(Route::currentRouteName() != 'home'): ?>
                        <div class="d-none d-xl-block align-self-stretch category-menu-icon-box ml-auto mr-0">
                            <div class="h-100 d-flex align-items-center" id="category-menu-icon">
                                <div class="dropdown-toggle navbar-light bg-light h-40px w-50px pl-2 rounded border c-pointer">
                                    <span class="navbar-toggler-icon"></span>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="d-lg-none ml-auto mr-0">
                    <a class="p-2 d-block text-reset" href="javascript:void(0);" data-toggle="class-toggle" data-target=".front-header-search">
                        <i class="las la-search la-flip-horizontal la-2x"></i>
                    </a>
                </div>

                <div class="flex-grow-1 front-header-search d-flex align-items-center bg-white">
                    <div class="position-relative flex-grow-1">
                        <form action="<?php echo e(route('search')); ?>" method="GET" class="stop-propagation">
                            <div class="d-flex position-relative align-items-center">
                                <div class="d-lg-none" data-toggle="class-toggle" data-target=".front-header-search">
                                    <button class="btn px-2" type="button"><i class="la la-2x la-long-arrow-left"></i></button>
                                </div>
                                <div class="input-group">
                                    <input type="text" class="border-0 border-lg form-control" id="search" name="q" placeholder="<?php echo e(translate('I am shopping for...')); ?>" autocomplete="off">
                                    <div class="input-group-append d-none d-lg-block">
                                        <button class="btn btn-primary" type="submit">
                                            <i class="la la-search la-flip-horizontal fs-18"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <div class="typed-search-box stop-propagation document-click-d-none d-none bg-white rounded shadow-lg position-absolute left-0 top-100 w-100" style="min-height: 200px">
                            <div class="search-preloader absolute-top-center">
                                <div class="dot-loader"><div></div><div></div><div></div></div>
                            </div>
                            <div class="search-nothing d-none p-3 text-center fs-16">

                            </div>
                            <div id="search-content" class="text-left">

                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-none d-lg-none ml-3 mr-0">
                    <div class="nav-search-box">
                        <a href="#" class="nav-box-link">
                            <i class="la la-search la-flip-horizontal d-inline-block nav-box-icon"></i>
                        </a>
                    </div>
                </div>

                <div class="d-none d-lg-block ml-3 mr-0">
                    <div class="" id="compare">
                        <?php echo $__env->make('frontend.partials.compare', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>

                <div class="d-none d-lg-block ml-3 mr-0">
                    <div class="" id="wishlist">
                        <?php echo $__env->make('frontend.partials.wishlist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>

                <div class="d-none d-lg-block  align-self-stretch ml-3 mr-0" data-hover="dropdown">
                    <div class="nav-cart-box dropdown h-100" id="cart_items">
                        <?php echo $__env->make('frontend.partials.cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="d-none d-lg-block  align-self-stretch ml-3 mr-0" data-hover="dropdown">
                    <div class="nav-cart-box dropdown h-100" id="cart_items">
                        <a href="javascript:void(0)" class="d-flex align-items-center text-reset h-100" data-toggle="dropdown" data-display="static">
                            <i class="la la-cog la-2x opacity-80"></i>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg p-0 stop-propagation">
    
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(isAdmin()): ?>
                                <div class="p-3 fs-15 fw-600 p-3 border-bottom">
                                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="text-reset py-2 d-inline-block opacity-60"><?php echo e(translate('My Panel')); ?></a>
                                </div>
                                <?php else: ?>
                                <div class="p-3 fs-15 fw-600 p-3 border-bottom">
                                    <a href="<?php echo e(route('dashboard')); ?>" class="text-reset py-2 d-inline-block opacity-60"><?php echo e(translate('My Panel')); ?></a>
                                </div>
                                <?php endif; ?>
                                <div class="p-3 fs-15 fw-600 p-3 border-bottom">
                                    <a href="<?php echo e(route('logout')); ?>" class="text-reset py-2 d-inline-block opacity-60"><?php echo e(translate('Logout')); ?></a>
                                </div>
                                <?php else: ?> 
                                <div class="p-3 fs-15 fw-600 p-3 border-bottom">
                                    <a href="<?php echo e(route('user.login')); ?>" class="text-reset py-2 d-inline-block opacity-60"><?php echo e(translate('Login')); ?></a>
                                </div>
                                <div class="p-3 fs-15 fw-600 p-3 border-bottom">
                                <a href="<?php echo e(route('user.registration')); ?>" class="text-reset py-2 d-inline-block opacity-60"><?php echo e(translate('Registration')); ?></a>
                                </div>
                            <?php endif; ?>
                               
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <?php if(Route::currentRouteName() != 'home'): ?>
        <div class="hover-category-menu position-absolute w-100 top-100 left-0 right-0 d-none z-3" id="hover-category-menu">
            <div class="container">
                <div class="row gutters-10 position-relative">
                    <div class="col-lg-3 position-static">
                        <?php echo $__env->make('frontend.partials.category_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="bg-white border-top border-gray-200 py-1">
            <div class="container">
                <ul class="list-inline mb-0 pl-0 mobile-hor-swipe text-center">
                    <li class="list-inline-item mr-0">
                        <a href="<?php echo e(route('home')); ?>" class="opacity-60 fs-14 px-3 py-2 d-inline-block fw-600 hov-opacity-100 text-reset">
                            الرئيسية
                        </a>
                    </li>
                    
                    
                    <?php 

                        $cats = App\Category::where([['published', 1], ['level',0]])->get();
                    ?>
                    <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                   
                    <li class="list-inline-item mr-0">
                        <a href="<?php echo e(route('home')); ?>" class="opacity-60 fs-14 px-3 py-2 d-inline-block fw-600 hov-opacity-100 text-reset">
                           <?php echo e($cat->name); ?>

                        </a>
                    </li>

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-inline-item mr-0">
                        <a href="<?php echo e(route('categories.all')); ?>" class="opacity-60 fs-14 px-3 py-2 d-inline-block fw-600 hov-opacity-100 text-reset">
                           كل الاقسام 
                        </a>
                    </li>

                    <li class="list-inline-item mr-0">
                        <a href="<?php echo e(route('brands.all')); ?>" class="opacity-60 fs-14 px-3 py-2 d-inline-block fw-600 hov-opacity-100 text-reset">
                           العلامات التجارية 
                        </a>
                    </li>
                   

                </ul>
            </div>
        </div>
</header>
<?php /**PATH /home/beoniuki/ar5as.net/demo/resources/views/frontend/inc/nav.blade.php ENDPATH**/ ?>