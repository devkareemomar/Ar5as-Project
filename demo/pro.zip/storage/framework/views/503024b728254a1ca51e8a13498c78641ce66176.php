<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
          <h1 class="h2"><?php echo e(translate('Order Details')); ?>

            <small> <?php echo e(translate('Tracking Screen')); ?></small>
               
          </h1>
        </div>
        <div>
            <div class="py-4"> 
                <div class="row gutters-5 text-center aiz-steps">
                    <div class="col <?php if($order->order_status == 'pending'): ?> active <?php else: ?> done <?php endif; ?>">
                        <div class="icon">
                            <i class="las la-file-invoice"></i>
                        </div>
                        <div class="title fs-12"><?php echo e(translate('Order placed')); ?></div>
                    </div>
                    <div class="col <?php if($order->order_status == 'picked'): ?> active <?php elseif($order->order_status == 'on_delivery' || $order->order_status == 'delivered'): ?> done <?php endif; ?>">
                        <div class="icon">
                            <i class="las la-newspaper"></i>
                        </div>
                    <div class="title fs-12"><?php echo e(translate('Picked UP')); ?></div>
                    </div>

                   
                    
                
                    <div class="col <?php if($order->order_status =='on_delivery'): ?> active <?php elseif($order->order_status == 'delivered'): ?> done <?php endif; ?>">
                        <div class="icon">
                            <i class="las la-truck"></i>
                        </div>
                        <div class="title fs-12"><?php echo e(translate('On delivery')); ?></div>
                    </div>
                    <div class="col <?php if($order->order_status == 'delivered'): ?> done <?php endif; ?>">
                        <div class="icon">
                            <i class="las la-clipboard-check"></i>
                        </div>
                        <div class="title fs-12"><?php echo e(translate('Delivered')); ?></div>
                    </div>
                
                </div>
            </div>
        </div>
        <div class="card-header row gutters-5">
  			<div class="col text-center text-md-left">
  			</div>
              <?php
                  $delivery_status = $order->orderDetails->first()->delivery_status;
                  $payment_status = $order->orderDetails->first()->payment_status;
              ?>
              
  			<div class="col-md-3 ml-auto">
                  <label for=update_delivery_status""><?php echo e(translate('Order Status')); ?></label>
                  <select class="form-control aiz-selectpicker"  data-minimum-results-for-search="Infinity" id="update_delivery_status">
                    
                      <option value="pending" <?php if($delivery_status == 'pending'): ?> selected <?php endif; ?>><?php echo e(translate('Pending')); ?></option>
                     
                      <option value="picked" <?php if($delivery_status == 'picked'): ?> selected <?php endif; ?>><?php echo e(translate('Picked Up')); ?></option>
                      
                    
                  </select>
  			</div>
  		</div> 
    	<div class="card-body">
        <div class="card-header row gutters-6">
  			<div class="col text-center text-md-left">
            <address>
                <strong class="text-main"><?php echo e(json_decode($order->shipping_address)->name); ?></strong><br>
                <?php echo e(json_decode($order->shipping_address)->email); ?><br>
                <?php echo e(json_decode($order->shipping_address)->phone); ?><br>
                <?php echo e(json_decode($order->shipping_address)->address); ?>, <?php echo e(json_decode($order->shipping_address)->city); ?>, <?php echo e(json_decode($order->shipping_address)->postal_code); ?><br>
                <?php echo e(json_decode($order->shipping_address)->country); ?>

            </address>
            <?php if($order->manual_payment && is_array(json_decode($order->manual_payment_data, true))): ?>
                <br>
                <strong class="text-main"><?php echo e(translate('Payment Information')); ?></strong><br>
                <?php echo e(translate('Name')); ?>: <?php echo e(json_decode($order->manual_payment_data)->name); ?>, <?php echo e(translate('Amount')); ?>: <?php echo e(single_price(json_decode($order->manual_payment_data)->amount)); ?>, <?php echo e(translate('TRX ID')); ?>: <?php echo e(json_decode($order->manual_payment_data)->trx_id); ?>

                <br>
                <a href="<?php echo e(uploaded_asset(json_decode($order->manual_payment_data)->photo)); ?>" target="_blank"><img src="<?php echo e(uploaded_asset(json_decode($order->manual_payment_data)->photo)); ?>" alt="" height="100"></a>
            <?php endif; ?>
  				</div>
  				<div class="col-md-4 ml-auto">
            <table>
        				<tbody>
            				<tr>
            					<td class="text-main text-bold"><?php echo e(translate('Order #')); ?></td>
            					<td class="text-right text-info text-bold">	<?php echo e($order->code); ?></td>
            				</tr>
            				<tr>
                                <td class="text-main text-bold"><?php echo e(translate('Order Status')); ?></td>
                                    <?php
                                      $status = $order->orderDetails->first()->delivery_status;
                                    ?>
            					<td class="text-right">
                                    <?php if($status == 'delivered'): ?>
                                        <span class="badge badge-inline badge-success"><?php echo e(translate(ucfirst(str_replace('_', ' ', $status)))); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-inline badge-info"><?php echo e(translate(ucfirst(str_replace('_', ' ', $status)))); ?></span>
                                    <?php endif; ?>
      					        </td>
            				</tr>
            				<tr>
            					<td class="text-main text-bold"><?php echo e(translate('Order Date')); ?>	</td>
            					<td class="text-right"><?php echo e(date('d-m-Y h:i A', $order->date)); ?></td>
            				</tr>
                    <!-- <tr>
            					<td class="text-main text-bold"><?php echo e(translate('Total amount')); ?>	</td>
            					<td class="text-right">
            						<?php echo e(single_price($order->grand_total)); ?>

            					</td>
            				</tr> -->
                    <tr>
            					<td class="text-main text-bold"><?php echo e(translate('Payment method')); ?></td>
            					<td class="text-right"><?php echo e(ucfirst(str_replace('_', ' ', $order->payment_type))); ?></td>
            				</tr>
        				</tbody>
    				</table>
  				</div>
  			</div>
    		<hr class="new-section-sm bord-no">
    		<div class="row">
    			<div class="col-lg-12 table-responsive">
    				<table class="table table-bordered invoice-summary">
        				<thead>
            				<tr class="bg-trans-dark">
                        <th class="min-col">#</th>
                        <th width="10%"><?php echo e(translate('Photo')); ?></th>
                        <th><?php echo e(translate('seller ID')); ?></th>
        					      <th class="text-uppercase"><?php echo e(translate('Product Name')); ?></th>
                        <th> <?php echo e(translate('variation')); ?> </th>
                        <th> <?php echo e(translate('Item Status')); ?> </th>
                        <th> <?php echo e(translate('Seller Available')); ?> </th>
                        
                          <th> <?php echo e(translate('At Stock')); ?> </th>
                      
                        
              					<th class="min-col text-center text-uppercase"><?php echo e(translate('Qty')); ?></th>
              					<th class="min-col text-center text-uppercase"><?php echo e(translate('Price')); ?></th>
        					       <th class="min-col text-right text-uppercase"><?php echo e(translate('Total')); ?></th>
            				</tr>
        				</thead>
        				<tbody>
                    <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($key+1); ?> 
                            
                           <?php if($orderDetail->is_deleted == 1): ?>
                            <i class="las la-times-circle" style="color:red ; font-size: 32px"></i>
                           <?php endif; ?>
                          
                        </td>
                        <td>
                          <?php if($orderDetail->product != null): ?>
                            <a href="<?php echo e(route('product', $orderDetail->product->slug)); ?>" target="_blank"><img height="50" src="<?php echo e(uploaded_asset($orderDetail->product->thumbnail_img)); ?>"></a>
                          <?php else: ?>
                            <strong><?php echo e(translate('N/A')); ?></strong>
                          <?php endif; ?>
                          </td>
                          <td> <?php echo e($orderDetail->seller_id); ?> </td>
                        <td>
                          <?php if($orderDetail->product != null): ?>
                            <strong><a href="<?php echo e(route('product', $orderDetail->product->slug)); ?>" target="_blank" class="text-muted"><?php echo e($orderDetail->product->getTranslation('name')); ?></a></strong>
                            
                          <?php else: ?>
                            <strong><?php echo e(translate('Product Unavailable')); ?></strong>
                          <?php endif; ?>
                        </td>
                        <td><?php echo e($orderDetail->variation); ?></td>
                         <td>
                            <?php if($orderDetail->item_status == null): ?>
                              <?php echo e(translate('Pending')); ?>

                            <?php else: ?>
                              <?php echo e($orderDetail->item_status); ?>

                            <?php endif; ?>
                         </td>


                         <td>
                              <?php if($orderDetail->item_status == 'available'): ?>
                              <i class="las la-check-circle" style="color:green; font-size: 32px"></i>
                             
                              <?php elseif($orderDetail->item_status == 'not_available'): ?>
                              <i class="las la-times-circle" style="color:red ; font-size: 32px"></i>  
                                  <?php if($payment_status == 'paid'  && $orderDetail->is_refunded == 0 ): ?>
                                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo"><?php echo e(translate('Refund Now')); ?></button>
                                  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                      <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                         <form action="<?php echo e(route('orders.refund_orderitem')); ?>" method="post">
                                         <?php echo csrf_field(); ?> 
                                          <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel"> <?php echo e(translate ('Refund Request')); ?></h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                              <span aria-hidden="true">&times;</span>
                                            </button>
                                          </div>
                                          <div class="modal-body">
                                              <input type="hidden" value="<?php echo e($orderDetail->id); ?>" name="order_detail_id">
                                              <input type="hidden" value="<?php echo e($order->user_id); ?>" name="user">
                                              <div class="form-group">
                                                <label for="recipient-name" class="col-form-label"><?php echo e(translate ('Refund Type')); ?>:</label>
                                                <div class="form-check">
                                                <input class="form-check-input" type="radio" name="refund_type" id="welt_type" value="welt" checked>
                                                <label class="form-check-label" for="welt_type">
                                                  <?php echo e(translate ('Wellt')); ?>

                                                </label>
                                              </div>
                                              <div class="form-check" >
                                                <input class="form-check-input" type="radio" name="refund_type" id="bank_type" value="bank" >
                                                <label class="form-check-label" for="bank_type" >
                                                   <?php echo e(translate ('Bank')); ?>

                                                </label>
                                              </div>
                                              </div>
                                              <div class="form-group bank">
                                                <label for="message-text" class="col-form-label"><?php echo e(translate('Bank Name')); ?>:</label>
                                                <select name="bank_id" class="js-example-basic-single form-control">
                                                    <?php
                                                    $banks = \App\Bank::get();
                                                        
                                                    ?>
                                                    <option class="form-control"  value="" ><?php echo e(translate('select Bank Name')); ?> </option>
                                                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <option class="form-control"  value="<?php echo e($bank->id); ?>" ><?php echo e(translate($bank->name)); ?> </option>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select><br>
                                                <input type="text" class="form-control" value="" name="bank_acc" placeholder="<?php echo e(translate('account number')); ?>">
                                              </div>

                                              <div class="form-group">
                                               <input type="text" class="form-control" value="<?php echo e($orderDetail->price+$orderDetail->tax); ?>" name="amount" placeholder="<?php echo e(translate('account number')); ?>" readonly>
                                              </div>
                                           
                                          </div>
                                          <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(translate('Close')); ?></button>
                                            <button type="submit" class="btn btn-primary"><?php echo e(translate('Refund Now')); ?> </button>
                                          </div>
                                          </form>
                                        </div>
                                      </div>
                                  </div>
                                  <?php endif; ?>
                                  <?php if($payment_status == 'unpaid' && $orderDetail->is_deleted == 0 ): ?>
                                  <div class="recalculate_order" data-id="<?php echo e($orderDetail->id); ?>" style="cursor:pointer; color:blue"><?php echo e(translate('remove and recalculate order')); ?>  </div>
                                  <?php elseif($orderDetail->is_deleted == 1 && $orderDetail->is_refunded == 0): ?>
                                    <span class="badg badg-danger"> <?php echo e(translate('Removed From Order')); ?></span>
                                  <?php elseif($orderDetail->is_deleted == 1 && $orderDetail->is_refunded == 1): ?>
                                    <span class="badg badg-danger"> <?php echo e(translate ('Refunded and Removed From Order')); ?></span>
                                  <?php endif; ?>  

                              <?php elseif($orderDetail->item_status == 'pending'): ?>
                              <i class="las la-exclamation-circle" style="color: rgb(71, 67, 67) ; font-size: 32px"></i>
                              <?php endif; ?>

                          </td>

                           <td>
                            <?php if($orderDetail->at_stock == 0): ?>
                             <i class="las la-times-circle" style="color:red ; font-size: 32px"></i>
                            <?php elseif($orderDetail->at_stock == 1): ?>
                              <i class="las la-check-circle" style="color:green; font-size: 32px"></i>
                            <?php endif; ?>
                            </td>
                           
                         
                        <td class="text-center"><?php echo e($orderDetail->quantity); ?></td>
                        <td class="text-center"><?php echo e(single_price($orderDetail->price/$orderDetail->quantity)); ?></td>
                        <td class="text-center"><?php echo e(single_price($orderDetail->price)); ?></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        				</tbody>
    				</table>
    			</div>
    		</div>
    		<div class="clearfix float-right">
    			<table class="table">
        			<tbody>
        			<tr>
        				<td>
        					<strong class="text-muted"><?php echo e(translate('Sub Total')); ?> :</strong>
        				</td>
        				<td>
        					<?php echo e(single_price($order->orderDetails->where('is_deleted' , '=' , 0)->sum('price'))); ?>

        				</td>
        			</tr>
        			<tr>
        				<td>
        					<strong class="text-muted"><?php echo e(translate('Tax')); ?> :</strong>
        				</td>
        				<td>
        					<?php echo e(single_price($order->orderDetails->where('is_deleted' , '=' , 0)->sum('tax'))); ?>

        				</td>
        			</tr>
                    <tr>
        				<td>
        					<strong class="text-muted"><?php echo e(translate('Shipping')); ?> :</strong>
        				</td>
        				<td>
        					<?php echo e(single_price($order->orderDetails->sum('shipping_cost'))); ?>

        				</td>
        			</tr>
                    <tr>
        				<td>
        					<strong class="text-muted"><?php echo e(translate('Coupon')); ?> :</strong>
        				</td>
        				<td>
        					<?php echo e(single_price($order->coupon_discount)); ?>

        				</td>
        			</tr>
        			<tr>
        				<td>
        					<strong class="text-muted"><?php echo e(translate('TOTAL')); ?> :</strong>
        				</td>
        				<td class="text-muted h5">
                <?php
        					$grand =  $order->grand_total - ($order->orderDetails->where('is_deleted' , '=' , 1)->sum('tax') + $order->orderDetails->where('is_deleted' , '=' , 1)->sum('price')) ;
        				?>
                <?php echo e(single_price($grand)); ?>

                </td>
        			</tr>
        			</tbody>
    			</table>
          <div class="text-right no-print">
            <a href="<?php echo e(route('customer.invoice.download', $order->id)); ?>" type="button" class="btn btn-icon btn-light"><i class="las la-print"></i></a>
          </div>
    		</div>

    	</div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
 <script type="text/javascript">
      $(".bank").hide();

      $("#bank_type").click(function(){
        $(".bank").show();
      });

       $("#welt_type").click(function(){
        $(".bank").hide();
      });
 </script>
    <script type="text/javascript">
        $('#update_delivery_status').on('change', function(){
            var order_id = <?php echo e($order->id); ?>;
            var status = $('#update_delivery_status').val();
            $.post('<?php echo e(route('orders.update_delivery_status')); ?>', {_token:'<?php echo e(@csrf_token()); ?>',order_id:order_id,status:status}, function(data){
                AIZ.plugins.notify('success', '<?php echo e(translate('Delivery status has been updated')); ?>');
            });
            location.reload().setTimeOut(1000);
        });

        $('#update_payment_status').on('change', function(){
            var order_id = <?php echo e($order->id); ?>;
            var status = $('#update_payment_status').val();
            $.post('<?php echo e(route('orders.update_payment_status')); ?>', {_token:'<?php echo e(@csrf_token()); ?>',order_id:order_id,status:status}, function(data){
                AIZ.plugins.notify('success', '<?php echo e(translate('Payment status has been updated')); ?>');
            });

            location.reload().setTimeOut(1000);
        });

        $('.recalculate_order').on('click', function(){
            
           
           //var order_id = <?php echo e($order->id); ?>;
            var order_id = $(this).data("id");
           // alert(order_id);
            $.post('<?php echo e(route('orders.recalculate_order')); ?>', {_token:'<?php echo e(@csrf_token()); ?>',order_id:order_id}, function(data){
                AIZ.plugins.notify('success', '<?php echo e(translate('Item status has been updated')); ?>');
            });

            location.reload().setTimeOut(1000);
        });
    

      function update_status(el){
            if(el.checked){
                var status = 1;
            }
            else{
                var status = 0;
            }
            $.post('<?php echo e(route('order.atstock')); ?>', {_token:'<?php echo e(csrf_token()); ?>', id:el.value, status:status}, function(data){
                if(data == 1){
                    AIZ.plugins.notify('success', '<?php echo e(translate('Item Status updated successfully')); ?>');
                }
                else{
                    AIZ.plugins.notify('danger', '<?php echo e(translate('Something went wrong')); ?>');
                }
            });
        }

    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\resources\views/backend/sales/all_orders/track_show.blade.php ENDPATH**/ ?>