<form action="<?php echo e(route('commissions.pay_to_seller')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="seller_id" value="<?php echo e($seller->id); ?>">
    <div class="modal-header">
    	<h5 class="modal-title h6"><?php echo e(translate('Pay to seller')); ?></h5>
    	<button type="button" class="close" data-dismiss="modal">
    	</button>
    </div>
    <div class="modal-body">
      <table class="table table-striped table-bordered" >
          <tbody>
              <tr>
                  <?php if($seller->admin_to_pay >= 0): ?>
                      <td><?php echo e(translate('Due to seller')); ?></td>
                      <td><?php echo e(single_price($seller->admin_to_pay)); ?></td>
                  <?php else: ?>
                      <td><?php echo e(translate('Due to admin')); ?></td>
                      <td><?php echo e(single_price(abs($seller->admin_to_pay))); ?></td>
                  <?php endif; ?>
              </tr>
              <?php if($seller->bank_payment_status == 1): ?>
                  <tr>
                      <td><?php echo e(translate('Bank Name')); ?></td>
                      <td><?php echo e($seller->bank->name); ?>  </td>
                  </tr> 
                  <tr>
                      <td><?php echo e(translate('Bank Account Name')); ?></td>
                      <td><?php echo e($seller->bank_acc_name); ?></td>
                  </tr>
                  <tr>
                      <td><?php echo e(translate('Bank Account Number')); ?></td>
                      <td><?php echo e($seller->bank_acc_no); ?></td>
                  </tr>
                  <tr>
                      <td><?php echo e(translate('Bank Routing Number')); ?></td>
                      <td><?php echo e($seller->bank_routing_no); ?></td>
                  </tr>
              <?php endif; ?>
          </tbody>
      </table>

      <?php if($seller->admin_to_pay > 0): ?>
          <div class="form-group row">
              <label class="col-md-3 col-from-label" for="amount"><?php echo e(translate('Amount')); ?></label>
              <div class="col-md-9">
                  <input type="number" lang="en" min="0" step="0.01" name="amount" id="amount" value="<?php echo e($seller->admin_to_pay); ?>" class="form-control" required>
              </div>
          </div>

          <div class="form-group row">
              <label class="col-md-3 col-from-label" for="payment_option"><?php echo e(translate('Payment Method')); ?></label>
              <div class="col-md-9">
                  <select name="payment_option" id="payment_option" class="form-control aiz-selectpicker" required>
                      <option value=""><?php echo e(translate('Select Payment Method')); ?></option>
                      <?php if($seller->cash_on_delivery_status == 1): ?>
                          <option value="cash"><?php echo e(translate('Cash')); ?></option>
                      <?php endif; ?>
                      <?php if($seller->bank_payment_status == 1): ?>
                          <option value="bank_payment"><?php echo e(translate('Bank Payment')); ?></option>
                      <?php endif; ?>
                  </select>
              </div>
          </div>
          <div class="form-group row" id="txn_div">
              <label class="col-md-3 col-from-label" for="txn_code"><?php echo e(translate('Txn Code')); ?></label>
              <div class="col-md-9">
                  <input type="text" name="txn_code" id="txn_code" class="form-control">
              </div>
          </div>
      <?php else: ?>
          <div class="form-group row">
              <label class="col-md-3 col-from-label" for="amount"><?php echo e(translate('Amount')); ?></label>
              <div class="col-md-9">
                  <input type="number" lang="en" min="0" step="0.01" name="amount" id="amount" value="<?php echo e(abs($seller->admin_to_pay)); ?>" class="form-control" required>
              </div>
          </div>
          <div class="form-group row" id="txn_div">
              <label class="col-md-3 col-from-label" for="txn_code"><?php echo e(translate('Txn Code')); ?></label>
              <div class="col-md-9">
                  <input type="text" name="txn_code" id="txn_code" class="form-control">
              </div>
          </div>
      <?php endif; ?>
    </div>
    <div class="modal-footer">
      <?php if($seller->admin_to_pay > 0): ?>
          <button type="submit" class="btn btn-primary"><?php echo e(translate('Pay')); ?></button>
      <?php else: ?>
          <button type="submit" class="btn btn-primary"><?php echo e(translate('Clear due')); ?></button>
      <?php endif; ?>
      <button type="button" class="btn btn-light" data-dismiss="modal"><?php echo e(translate('Cancel')); ?></button>
    </div>
</form>

<script>
  $(document).ready(function(){
      $('#payment_option').on('change', function() {
        if ( this.value == 'bank_payment')
        {
          $("#txn_div").show();
        }
        else
        {
          $("#txn_div").hide();
        }
      });
      $("#txn_div").hide();
      AIZ.plugins.bootstrapSelect('refresh');
  });
</script>
<?php /**PATH C:\xampp\htdocs\demo\resources\views/backend/sellers/payment_modal.blade.php ENDPATH**/ ?>