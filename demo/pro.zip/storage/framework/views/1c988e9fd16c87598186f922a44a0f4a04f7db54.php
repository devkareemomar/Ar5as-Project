 

<?php $__env->startSection('content'); ?>

    <section class="py-5">
        <div class="container-fluid">
            <div class="d-flex align-items-start">
                <?php echo $__env->make('frontend.inc.user_side_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="aiz-user-panel">

                    <div class="card">
                        <div class="card-body p-3">
                                <table class="table aiz-table mb-0">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th data-breakpoints="lg"><?php echo e(translate('Product Name ')); ?></th>
                                            <th data-breakpoints="lg"><?php echo e(translate('Quantaty')); ?></th>
                                            <th data-breakpoints="lg"><?php echo e(translate('Alert Quantaty')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                      <?php echo e($key + 1); ?>

                                                    </td>
                                                    <td> 
                                                        
                                                    <?php 
                                                     $name =   App\Product::where('id', $product->product_id )->select('name')->get();

                                                    ?>
                                                    <?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                         <?php echo e($nam->name); ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                                    
                                                    </td>
                                                    <td><?php echo e($product->qty); ?></td>
                                                    <td><?php echo e($product->alert_qty); ?></td>
                                                  
                                                </tr>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="aiz-pagination">
                                
                              	</div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/beoniuki/ar5as.net/demo/resources/views/frontend/user/seller/alert_qty.blade.php ENDPATH**/ ?>