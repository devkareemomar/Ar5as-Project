<div class="modal-header">
  <h5 class="modal-title h6"><?php echo e(translate('Seller Message')); ?></h5>
  <button type="button" class="close" data-dismiss="modal">
  </button>
</div>
<div class="modal-body">
    <div class="from-group row">
        <div class="col-lg-2">
            <label><?php echo e(translate('Message')); ?></label>
        </div>
        <div class="col-lg-10">
            <textarea name="meta_description" rows="8" class="form-control"><?php echo e($seller_withdraw_request->message); ?></textarea>
        </div>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-light" data-dismiss="modal"><?php echo e(translate('Cancel')); ?></button>
</div>
<?php /**PATH C:\xampp\htdocs\demo\resources\views/backend/sellers/seller_withdraw_requests/withdraw_message_modal.blade.php ENDPATH**/ ?>