<?php $__env->startSection('content'); ?>

    <section class="py-5">
        <div class="container-fluid">
            <div class="d-flex align-items-start">
                <?php echo $__env->make('frontend.inc.user_side_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="aiz-user-panel">

                    <div class="card">
                        <div class="modal-header">
                            <h5 class="modal-title strong-600 heading-5"><?php echo e(translate('Order id')); ?>: <?php echo e($order->code); ?></h5>
                            <h5 class="modal-title strong-600 heading-5"><?php echo e(translate('Order date')); ?>: <?php echo e(date('d-m-Y H:i A', $order->date)); ?></h5>
                                                  
                           
                        </div>

                        <?php
                            $status = $order->orderDetails->where('seller_id', Auth::user()->id)->first()->delivery_status;
                            $payment_status = $order->orderDetails->where('seller_id', Auth::user()->id)->first()->payment_status;
                            $refund_request_addon = \App\Addon::where('unique_identifier', 'refund_request')->first();
                        ?>

                        <div class="modal-body gry-bg px-3 pt-0">
                            <div class="py-4">
                                <div class="row gutters-5 text-center aiz-steps">
                                    <div class="col <?php if($status == 'pending'): ?> active <?php else: ?> done <?php endif; ?>">
                                        <div class="icon">
                                            <i class="las la-file-invoice"></i>
                                        </div>
                                        <div class="title fs-12"><?php echo e(translate('Order placed')); ?></div>
                                    </div>
                                    
                                    <div class="col <?php if($order->order_status == 'picked'): ?> active <?php elseif($order->order_status == 'on_delivery' || $order->order_status == 'delivered'): ?> done <?php endif; ?>">
                                        <div class="icon">
                                            <i class="las la-newspaper"></i>
                                        </div>
                                    <div class="title fs-12"><?php echo e(translate('Picked UP')); ?></div>
                                    </div>
                                    
                                    
                                
                                    <div class="col <?php if($status == 'on_delivery'): ?> active <?php elseif($status == 'delivered'): ?> done <?php endif; ?>">
                                        <div class="icon">
                                            <i class="las la-truck"></i>
                                        </div>
                                        <div class="title fs-12"><?php echo e(translate('On delivery')); ?></div>
                                    </div>
                                    <div class="col <?php if($status == 'delivered'): ?> done <?php endif; ?>">
                                        <div class="icon">
                                            <i class="las la-clipboard-check"></i>
                                        </div>
                                        <div class="title fs-12"><?php echo e(translate('Delivered')); ?></div>
                                    </div>
                                
                                </div>
                            </div>
                        
                            <div class="row mt-5">
                                
                                <div class="offset-lg-2 col-lg-4 col-sm-6">
                                    <div class="form-group">
                                        <input class="form-control"  placeholder="<?php echo e($payment_status); ?>" disabled>
                                        
                                        <label><?php echo e(translate('Payment Status')); ?></label>
                                    </div>
                                </div>
                            
                                <div class="col-lg-4 col-sm-6">
                                    <div class="form-group">
                                        <input class="form-control"  placeholder="<?php echo e($status); ?>" disabled>
                                        
                                        <label><?php echo e(translate('Order Status')); ?></label>
                                    </div>
                                </div>
                            </div>
                        
                            
                            

                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card mt-4">
                                        <div class="card-header">
                                        <b class="fs-15"><?php echo e(translate('Order Details')); ?></b>
                                        </div>
                                        <div class="card-body pb-0">
                                            <table class="table table-borderless table-responsive">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th width="40%"><?php echo e(translate('Product')); ?></th>
                                                        <th><?php echo e(translate('Variation')); ?></th>
                                                        <th><?php echo e(translate('Quantity')); ?></th>
                                                        
                                                        <th><?php echo e(translate('Price')); ?></th>
                                                        

                                                        <th><?php echo e(translate('Item Status')); ?></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $order->orderDetails->where('seller_id', Auth::user()->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($key+1); ?></td>
                                                            <td>
                                                                <?php if($orderDetail->product != null): ?>
                                                                    <a href="<?php echo e(route('product', $orderDetail->product->slug)); ?>" target="_blank"><?php echo e($orderDetail->product->getTranslation('name')); ?></a>
                                                                <?php else: ?>
                                                                    <strong><?php echo e(translate('Product Unavailable')); ?></strong>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <?php echo e($orderDetail->variation); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($orderDetail->quantity); ?>

                                                            </td>
                                                            
                                                            <td><?php echo e($orderDetail->price); ?></td>
                                                            
                                                            <td>
                                                                <?php if($orderDetail->item_status == 'pending' || $orderDetail->item_status == null): ?>
                                                                <label> <?php echo e(translate('Item Availability')); ?> </label> <br> 
                                                                <input class="available_yes" data-id="<?php echo e($orderDetail->id); ?>" type="radio"  name="item_status" value="available">
                                                                <label ><?php echo e(translate('Yes')); ?></label>
                                                                <input class="available_no" data-id="<?php echo e($orderDetail->id); ?>" type="radio"  name="item_status" value="not_available">
                                                                <label ><?php echo e(translate('No')); ?></label>
                                                                <?php else: ?>
                                                                    <?php echo e($orderDetail->item_status); ?>

                                                            
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="container">
                                     <?php
                                    $seller = Auth::user()->id;
                                ?>
                                <a href="<?php echo e(route('seller.invoice.download', $order->id .'/'. $seller)); ?>" class="btn btn-soft-primary btn-icon btn-circle btn-sm" title="<?php echo e(translate('Download Invoice')); ?>">
                                    <i class="las la-print"></i>
                                </a>
                                </div>
                               
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $('#update_delivery_status').on('change', function(){
        var order_id = <?php echo e($order->id); ?>;
        var status = $('#update_delivery_status').val();
        $.post('<?php echo e(route('orders.update_delivery_status')); ?>', {_token:'<?php echo e(@csrf_token()); ?>',order_id:order_id,status:status}, function(data){
            $('#order_details').modal('hide');
            AIZ.plugins.notify('success', '<?php echo e(translate('Order status has been updated')); ?>');
            location.reload().setTimeOut(500);
        });
    });

    $('#update_payment_status').on('change', function(){
        var order_id = <?php echo e($order->id); ?>;
        var status = $('#update_payment_status').val();
        $.post('<?php echo e(route('orders.update_payment_status')); ?>', {_token:'<?php echo e(@csrf_token()); ?>',order_id:order_id,status:status}, function(data){
            $('#order_details').modal('hide');
            //console.log(data);
            AIZ.plugins.notify('success', '<?php echo e(translate('Payment status has been updated')); ?>');
            location.reload().setTimeOut(500);
        });
    });


    $('.available_yes').on('click', function(){
        confirm("<?php echo e(translate('Are You Sure')); ?>");
        var order_id = <?php echo e($order->id); ?>;
        var status = $('.available_yes').val();
        var id = $(this).attr("data-id");
         //console.log(status);
        $.post('<?php echo e(route('orders.available_yes')); ?>', {_token:'<?php echo e(@csrf_token()); ?>',order_id:order_id,status:status,id:id}, function(data){
            $('#order_details').modal('hide');
            //console.log(data);
            AIZ.plugins.notify('success', '<?php echo e(translate('Available status has been updated')); ?>');
            location.reload().setTimeOut(500);
           
        });
    });

    $('.available_no').on('click', function(){
         confirm("<?php echo e(translate('Are You Sure')); ?>");
        var order_id = <?php echo e($order->id); ?>;
        var status = $('.available_no').val();
        var id = $(this).attr("data-id");
         //console.log(status);
        $.post('<?php echo e(route('orders.available_yes')); ?>', {_token:'<?php echo e(@csrf_token()); ?>',order_id:order_id,status:status,id:id}, function(data){
            $('#order_details').modal('hide');
            //console.log(data);
            AIZ.plugins.notify('success', '<?php echo e(translate('Available status has been updated')); ?>');
            location.reload().setTimeOut(500);
           
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\resources\views/frontend/user/seller/order_details_seller.blade.php ENDPATH**/ ?>