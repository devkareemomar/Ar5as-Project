

<?php $__env->startSection('content'); ?> 

<div class="col-lg-8 mx-auto"> 
    <div class="card"> 
        <div class="card-header">
            <h5 class="mb-0 h6"><?php echo e(translate('Sub Category Information')); ?></h5>
        </div>
        <div class="card-body">
            <form class="form-horizontal" action="<?php echo e(route('subcategories.store')); ?>" method="POST" enctype="multipart/form-data">
            	<?php echo csrf_field(); ?>
                <?php if($errors->any()): ?>
                <div class="bs-component">
                    <div class="alert alert-danger alert-dismissible ">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button class="close" type="button" data-dismiss="alert">×</button><strong><?php echo e($error); ?>!</strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>  
                <?php endif; ?>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label"><?php echo e(translate('Name')); ?></label>
                    <div class="col-md-9">
                        <input type="text" placeholder="<?php echo e(translate('Name')); ?>" id="name" name="name" class="form-control" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label"><?php echo e(translate('Parent Category')); ?></label>
                    <div class="col-md-9">
                        <select class="select2 form-control aiz-selectpicker" name="category_id" data-toggle="select2" data-placeholder="Choose ..." data-live-search="true">
                            <option><?php echo e(translate('Select Category')); ?></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->getTranslation('name')); ?></option>
                               
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                 <?php
				    $refund_request_addon = \App\Addon::where('unique_identifier', 'refund_request')->first();
				?>
				<?php if($refund_request_addon != null && $refund_request_addon->activated == 2): ?>
					<div class="form-group row">
						<label class="col-md-3 col-from-label"><?php echo e(translate('Refundable')); ?></label>
						<div class="col-md-8">
                          <label class="aiz-switch aiz-switch-success mb-0">
                              <input type="checkbox" name="refundable" checked>
                              <span></span>
                          </label>
						</div>
					</div>
				<?php endif; ?>
                
               
                <div class="form-group mb-0 text-right">
                    <button type="submit" class="btn btn-primary"><?php echo e(translate('Save')); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/beoniuki/ar5as.net/demo/resources/views/backend/product/subcategories/create.blade.php ENDPATH**/ ?>