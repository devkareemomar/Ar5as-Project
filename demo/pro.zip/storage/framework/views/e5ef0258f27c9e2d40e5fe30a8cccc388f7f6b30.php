<?php $__env->startSection('content'); ?>
 
<div class="card">
  <div class="card-header">
      <h5 class="mb-0 h6"><?php echo e(translate('Seller Verification')); ?></h5>
      <?php if($seller->verification_status != 1): ?>
          
    
      <div class="pull-right clearfix"> 
        <a href="<?php echo e(route('sellers.reject', $seller->id)); ?>" class="btn btn-default d-innline-block"><?php echo e(translate('Reject')); ?></a></li>
        <a href="<?php echo e(route('sellers.approve', $seller->id)); ?>" class="btn btn-circle btn-dark d-innline-block"><?php echo e(translate('Accept')); ?></a>
      </div>

        <?php endif; ?>
  </div>
  <div class="card-body row">
      <div class="col-md-5"> 
          <h6 class="mb-4"><?php echo e(translate('User Info')); ?></h6>
          <p class="text-muted">
              <strong><?php echo e(translate('Name')); ?> :</strong>
              <span class="ml-2"><?php echo e($seller->user->name); ?></span>
          </p> 
          <p class="text-muted">
              <strong><?php echo e(translate('Email')); ?> :</strong>
              <span class="ml-2"><?php echo e($seller->user->email); ?></span>
          </p>
          <p class="text-muted"> 
              <strong><?php echo e(translate('Address')); ?> :</strong>
              <span class="ml-2"><?php echo e($seller->user->address); ?></span>
          </p>
          <p class="text-muted">
              <strong><?php echo e(translate('Phone')); ?> :</strong>
              <span class="ml-2"><?php echo e($seller->user->phone); ?></span>
          </p>

           <p class="text-muted"> 
                <strong><?php echo e(translate('Seller Type')); ?> :</strong>
                <span class="ml-2">
                      <?php if( $seller->seller_type == 1): ?>

                    <?php echo e(translate('Individual')); ?>

                   <?php elseif($seller->seller_type == 2): ?>
                    <?php echo e(translate('Company')); ?>

                   <?php endif; ?>
                   
                </span>
          </p>
          <br>

          <h6 class="mb-4"><?php echo e(translate('Shop Info')); ?></h6>
          <p class="text-muted">
              <strong><?php echo e(translate('Shop Name')); ?> :</strong>
              <span class="ml-2"><?php echo e($seller->user->shop->name); ?></span>
          </p>
          <p class="text-muted">
              <strong><?php echo e(translate('Address')); ?> :</strong>
              <span class="ml-2"><?php echo e($seller->user->shop->address); ?></span>
          </p>

          <h6 class="mb-4"><?php echo e(translate('Payment Info')); ?></h6>
           <p class="text-muted">
              <strong><?php echo e(translate('Bank Name')); ?> :</strong>
              <span class="ml-2"><?php echo e($bank->name); ?></span> 
          </p>
          <p class="text-muted">
              <strong><?php echo e(translate('Bank Account Name')); ?> :</strong>
              <span class="ml-2"><?php echo e($seller->bank_acc_name); ?></span>
          </p>
          <p class="text-muted">
              <strong><?php echo e(translate('Bank Account Number')); ?> :</strong>
              <span class="ml-2"><?php echo e($seller->bank_acc_no); ?></span>
          </p>
          <p class="text-muted">
              <strong><?php echo e(translate('Bank Routing Number')); ?> :</strong>
              <span class="ml-2"><?php echo e($seller->bank_routing_no); ?></span>
          </p>

          <p class="text-muted">
              <strong><?php echo e(translate('I Ban Number')); ?> :</strong>
              <span class="ml-2"><?php echo e($seller->ipan); ?></span>
          </p>
      </div>    
      <div class="col-md-5">
           <h6 class="mb-4"><?php echo e(translate('Account Papers')); ?></h6>
           <?php if( $seller->seller_type == 1): ?> 
           <p><strong><?php echo e(translate('National Id Photo')); ?></strong></p> <br> 
           <p>
                
                <a href="<?php echo e(asset('public/uploads/seller/'.$seller->user_id. '/data/' .$seller->national_id_photo )); ?>" class="btn btn-primary" download=""> <?php echo e(translate('Download')); ?> </a>
                <a href="<?php echo e(asset('public/uploads/seller/'.$seller->user_id. '/data/' .$seller->national_id_photo )); ?>" class="btn btn-success" target="blank"> <?php echo e(translate('Show')); ?> </a>
           </p>
                <?php elseif($seller->seller_type == 2): ?>
                <p class="text-muted">
                    <strong><?php echo e(translate('Company Name')); ?></strong>
                    <span class="ml-2"><?php echo e($seller->company_name); ?></span>
                </p>
                 
                 <p><strong><?php echo e(translate('National Id Photo')); ?></strong></p>
                 <p>
                <a href="<?php echo e(asset('public/uploads/seller/'.$seller->user_id. '/data/' .$seller->national_id_photo )); ?>" class="btn btn-primary" download=""> <?php echo e(translate('Download')); ?> </a>
                <a href="<?php echo e(asset('public/uploads/seller/'.$seller->user_id. '/data/' .$seller->national_id_photo )); ?>" class="btn btn-success" target="blank"> <?php echo e(translate('Show')); ?> </a>
                
                 </p>


                <p><strong><?php echo e(translate('Taxs Photo')); ?></strong></p>
                <p>
                <a href="<?php echo e(asset('public/uploads/seller/'.$seller->user_id. '/data/' .$seller->tax_photo )); ?>" class="btn btn-primary" download=""> <?php echo e(translate('Download')); ?> </a>
                <a href="<?php echo e(asset('public/uploads/seller/'.$seller->user_id. '/data/' .$seller->tax_photo )); ?>" class="btn btn-success" target="blank"> <?php echo e(translate('Show')); ?> </a>
                
                </p>

                <p><strong><?php echo e(translate('Commercial Register Photo')); ?></strong></p>
                <p>
                <a href="<?php echo e(asset('public/uploads/seller/'.$seller->user_id. '/data/' .$seller->commercial_register_photo )); ?>" class="btn btn-primary" download=""> <?php echo e(translate('Download')); ?> </a>
                <a href="<?php echo e(asset('public/uploads/seller/'.$seller->user_id. '/data/' .$seller->commercial_register_photo )); ?>" class="btn btn-success" target="blank"> <?php echo e(translate('Show')); ?> </a>
                </p>
                
           <?php endif; ?> 
      </div> 
     
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\resources\views/backend/sellers/verification.blade.php ENDPATH**/ ?>